import json, os, uuid, boto3, datetime
table = boto3.resource('dynamodb').Table(os.environ['TABLE_NAME'])

def lambda_handler(event, context):
    body = {}
    try:
        if event.get("body"):
            body = json.loads(event["body"])
    except Exception:
        pass
    item = {
        "id": str(uuid.uuid4()),
        "created_at": datetime.datetime.utcnow().isoformat()+"Z",
        "payload": body
    }
    table.put_item(Item=item)
    return {"statusCode":200,"headers":{"Content-Type":"application/json"},
            "body": json.dumps({"ok": True, "item": item})}
